document.getElementById("fitnessForm").addEventListener("submit", function(event) {
    event.preventDefault();

    try {
        const age = document.querySelector('input[name="age"]:checked')?.value;
        const gender = document.querySelector('input[name="gender"]:checked')?.value;
        const height = document.querySelector('input[name="height"]:checked')?.value;
        const weight = document.querySelector('input[name="weight"]:checked')?.value;
        const activity = parseFloat(document.querySelector('input[name="activity"]:checked')?.value);
        const goal = parseFloat(document.querySelector('input[name="goal"]:checked')?.value);

        if (!age || !gender || !height || !weight || isNaN(activity) || isNaN(goal)) {
            document.getElementById("result").innerText = "Please answer all required questions!";
            return;
        }

        const ageMap = { below18: 15, "18-30": 24, "31-50": 40, above50: 60 };
        const heightMap = { below150: 130, "150-170": 160, "171-190": 181, above190: 195 };
        const weightMap = { below50: 42.7, "50-70": 60, "71-90": 80.5, above90: 92.65 };

        const ageNum = ageMap[age];
        const heightNum = heightMap[height];
        const weightNum = weightMap[weight];

        let bmr = gender === "female" 
            ? 10 * weightNum + 6.25 * heightNum - 5 * ageNum - 161 
            : 10 * weightNum + 6.25 * heightNum - 5 * ageNum + 5;

        const tdee = bmr * activity;
        const calorieIntake = tdee * goal;

        document.getElementById("result").innerText = `Your recommended daily calorie intake is: ${calorieIntake.toFixed(2)} calories.`;

    } catch (error) {
        document.getElementById("result").innerText = "An error occurred! Please try again.";
        console.error(error);
    }
});
