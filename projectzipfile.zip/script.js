var txt = document.querySelector("span");

function getBMICategory() {
  var weight = document.querySelector("#box2").value; // Weight (kg)
  var height = document.querySelector("#box1").value; // Height (m)
  var age = document.querySelector("#box3").value; // Age (years)
  var gender = document.querySelector('input[name="options"]:checked');

  // Validate inputs
  if (!weight || !height || !age || !gender) {
    txt.innerText = 'Please fill all fields and select gender!';
    return;
  }

  weight = parseFloat(weight);
  height = parseFloat(height);
  age = parseInt(age);

  if (isNaN(weight) || isNaN(height) || isNaN(age)) {
    txt.innerText = 'Please enter valid numbers!';
    return;
  }

  // Calculate BMI
  var bmi = (weight / (height * height));  // BMI = weight (kg) / height^2 (m^2)
  console.log("BMI: ", bmi);  // Log BMI for debugging

  let ffat, mfat;

  // Calculate Body Fat Percentage based on gender
  if (gender.value === "f") {
    ffat = ((1.20 * bmi) + (0.23 * age)) - 5.4; // Female fat percentage formula
    console.log("Female Fat Percentage (ffat): ", ffat);  // Log body fat for debugging
    female(ffat, bmi);  // Call female function with body fat and BMI
  } else if (gender.value === "m") {
    mfat = ((1.20 * bmi) + (0.23 * age)) - 16.2; // Male fat percentage formula
    console.log("Male Fat Percentage (mfat): ", mfat);  // Log body fat for debugging
    male(mfat, bmi);  // Call male function with body fat and BMI
  } else {
    txt.innerText = 'Please select a valid gender.';
  }
}

function female(ffat, bmi) {
  console.log("Evaluating female category with BMI: ", bmi, " and body fat: ", ffat);

  // For females: Normal weight BMI is between 18.5 and 24.9, and body fat between 18% and 30%
  if (bmi >= 25 || ffat >= 32) {
    txt.innerText = 'Overweight';
  } else if (bmi >= 18.5 && bmi < 25 && (ffat >= 18 && ffat <= 30)) {  // Adjusted fat percentage range
    txt.innerText = 'Normal Weight';
  } else if (bmi < 18.5) {
    txt.innerText = 'Underweight';
  } else {
    txt.innerText = 'Invalid Input';  // This case can catch any logic errors
  }
}

function male(mfat, bmi) {
  console.log("Evaluating male category with BMI: ", bmi, " and body fat: ", mfat);

  // For males: Normal weight BMI is between 18.5 and 24.9, and body fat between 10% and 24%
  if (bmi >= 25 || mfat >= 25) {
    txt.innerText = 'Overweight';
  } else if (bmi >= 18.5 && bmi < 25 && (mfat >= 10 && mfat <= 24)) {  // Adjusted fat percentage range
    txt.innerText = 'Normal Weight';
  } else if (bmi < 18.5) {
    txt.innerText = 'Underweight';
  } else {
    txt.innerText = 'Invalid Input';  // This case can catch any logic errors
  }
}
